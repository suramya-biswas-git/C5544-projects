package org.anudip.jwtSecurityApplication.service;

import java.util.ArrayList;

import org.anudip.jwtSecurityApplication.bean.JwtUser;
import org.anudip.jwtSecurityApplication.bean.UserDto;
import org.anudip.jwtSecurityApplication.dao.JwtUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class JwtUserService implements UserDetailsService  {
	@Autowired
	private JwtUserRepository repository;
	
	@Autowired
	private PasswordEncoder bcryptEncoder;

	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		JwtUser jwtUser=repository.findByUsername(username);
		if (jwtUser == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		User user=new User(jwtUser.getUsername(), jwtUser.getPassword(), new ArrayList<>());
		return user;
	}
	
	public JwtUser save(UserDto user) {
		JwtUser newUser = new JwtUser(user.getUsername(), bcryptEncoder.encode(user.getPassword()));
		newUser.setUsername(user.getUsername());
		return repository.save(newUser);
	}

	
	
	
}
